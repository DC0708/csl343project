/**
 * Author: Aditya Abhas
 * Song Fetch done by Abhishek Raj (broadcast and domusic functions)
 *Posting and integration by DC
 * */

package csl343.group1.Surround;
import android.content.Intent;
import android.support.v7.app.ActionBarActivity ;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.app.ActionBar;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.w3c.dom.Text;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends ActionBarActivity {

    public final static String EXTRA_MESSAGE = "csl343.group1.Surround.MESSAGE";

    private TextView txtName;
    private TextView txtEmail;
    private Button btnLogout;
    public Button buttonFetch;
    private TextView songName;

    private SQLiteManager db;
    private SessionManager session;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        buttonFetch = (Button) findViewById(R.id.buttonFetch);
        txtName = (TextView) findViewById(R.id.name);
        txtEmail = (TextView) findViewById(R.id.email);
        btnLogout = (Button) findViewById(R.id.btnLogout);
        songName = (TextView) findViewById(R.id.songName);

        // SqLite database handler
        db = new SQLiteManager(getApplicationContext());

        // session manager
        session = new SessionManager(getApplicationContext());

        if (!session.isLoggedIn()) {
            logoutUser();
        }

        // Fetching user details from sqlite
        HashMap<String, String> user = db.getUserDetails();

        String name = user.get("name");
        String email = user.get("email");

        // Displaying the user details on the screen
        txtName.setText(name);
        //	txtEmail.setText(email);

        doMusicStuff();

        // Logout button click event
        btnLogout.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                logoutUser();
            }
        });

        buttonFetch.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                fetch_songs(v);
            }
        });

    }
/*
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();



        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

*/


    /**
     * Logging out the user. Will set isLoggedIn flag to false in shared
     * preferences Clears the user data from sqlite users table
     * */
    private void logoutUser() {
        session.setLoginStatus(false);

        db.deleteUsers();

        // Launching the login activity
        Intent intent = new Intent(MainActivity.this, Login.class);
        startActivity(intent);
        finish();
    }

    private BroadcastReceiver mReceiver = new BroadcastReceiver() {

        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            String cmd = intent.getStringExtra("command");
            Log.v("tag ", action + " / " + cmd);
            String artist = intent.getStringExtra("artist");
            String album = intent.getStringExtra("album");
            String track = intent.getStringExtra("track");
          //  artist = "Demo Artist";
          //  album = "Demo album";
          //  track = "Demo track";
            Log.v("tag", artist + ":" + album + ":" + track);
            songName.setText( track);

            updateSongOnServer(artist,album,track);

        }
    };


    public void doMusicStuff() {
        IntentFilter iF = new IntentFilter();
        iF.addAction("com.android.music.metachanged");
        iF.addAction("com.android.music.playstatechanged");
        iF.addAction("com.android.music.playbackcomplete");
        iF.addAction("com.android.music.queuechanged");
        iF.addAction("com.android.music.metachanged");

        iF.addAction("com.htc.music.metachanged");

        iF.addAction("fm.last.android.metachanged");
        iF.addAction("com.sec.android.app.music.metachanged");
        iF.addAction("com.nullsoft.winamp.metachanged");
        iF.addAction("com.amazon.mp3.metachanged");
        iF.addAction("com.miui.player.metachanged");
        iF.addAction("com.real.IMP.metachanged");
        iF.addAction("com.sonyericsson.music.metachanged");
        iF.addAction("com.rdio.android.metachanged");
        iF.addAction("com.samsung.sec.android.MusicPlayer.metachanged");
        iF.addAction("com.andrew.apollo.metachanged");

        registerReceiver(mReceiver, iF);
    }

    public void updateSongOnServer(final String artist,final String album,final String track){


        final ArrayList<Double> locate;
        locate=sendMessage();
        HashMap<String, String> user = db.getUserDetails();

        final String uid = user.get("uid");


        String tag_string_req = "req_register";


        StringRequest stringRequest = new StringRequest(Request.Method.POST,
                ServerConfig.REGISTER_URL, new Response.Listener<String>() {

            @Override
            public void onResponse(String serverResponse) {

                try {
                    Log.d("ServerResponse", "Register Response: " + serverResponse.toString());
                    JSONObject jObj = new JSONObject(serverResponse);
                    boolean error = jObj.getBoolean("error");
                    if (error) {
                        String errorMessage = jObj.getString("error_msg");
         //               Toast.makeText(getApplicationContext(),
           //                     errorMessage, Toast.LENGTH_LONG).show();
                    }


                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError songUpdateError) {
             //   Toast.makeText(getApplicationContext(),
                      //if()
                      //Log.d("errorrrr...taggg11",songUpdateError.getMessage());

            }
        }) {

            @Override																																																																																																																																																																	
            protected Map<String, String> getParams() {
                // POST parameters to registration url
                Log.d("long",locate.get(0).toString()+ " " + uid +  "  " + album + artist + track );
                Map<String, String> parameters = new HashMap<String, String>();
                parameters.put("tag", "getsongs");
                parameters.put("uid",uid);
                parameters.put("artist", artist);
                parameters.put("album", album);
                parameters.put("track", track);
                parameters.put("lat", locate.get(0).toString());
                parameters.put("long", locate.get(1).toString());

                return parameters;
            }

        };

        AppManager.getInstance().addToRequestQueue(stringRequest, tag_string_req);
    }

    /* Geolocation starts from here */

    public ArrayList sendMessage(){
        Log.d("msgsend","yoo");
    /*    Intent intent = new Intent(this, DisplayActivityMessage.class);
        String message = "New Activity called on Button click!";
        intent.putExtra(EXTRA_MESSAGE,message);
        startActivity(intent);
    */
        GPSTracker gps;
        gps = new GPSTracker(MainActivity.this);
        ArrayList<Double> list = new ArrayList<Double>(3);

        if (gps.canGetLocation())
        {
            double latitude = gps.getLatitude();
            double longitude = gps.getLongitude();
            Log.d("logit","doneeee");
            list.add(latitude);
            list.add(longitude);
            return list;
          /*  String dispMessage = "Your Location is: \nLatitude: " + latitude + "\nLongitude: " + longitude;
            TextView t = new TextView(this);
            t.setTextSize(35);
            t.setText(dispMessage);
            setContentView(t);
            */
        }

        else{

            gps.showSettingsAlert();
            return list;
        }




    }


    public void fetch_songs(final View V){

        Log.d("aaloo","fetchsongs");
        final ArrayList<Double> locate;
        locate=sendMessage();
        HashMap<String, String> user = db.getUserDetails();

        final String uid = user.get("uid");


        String tag_string_req = "req_register";


        StringRequest stringRequest = new StringRequest(Request.Method.POST,
                ServerConfig.REGISTER_URL, new Response.Listener<String>() {

            @Override
            public void onResponse(String serverResponse) {

                try {
                    Intent I = new Intent(V.getContext(), WeatherActivity.class);
                    Log.d("ServerResponse", "Register Response: " + serverResponse.toString());
                    JSONArray jObj = new JSONArray(serverResponse);
                    //Context context = V.getContext();
                    I.putExtra("json", jObj.toString());
                    startActivity(I);
                    Log.d("ServerResponse", "Register Response: " + jObj.toString());
//                    boolean error = jObj.getBoolean("error");
                    /*    if (error) {
                        //String errorMessage = jObj.getString("error_msg");
                        //               Toast.makeText(getApplicationContext(),
                        //                     errorMessage, Toast.LENGTH_LONG).show();
                    }*/


                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError songUpdateError) {
                //   Toast.makeText(getApplicationContext(),
                //if()
//                Log.d("errorrrr...taggg",songUpdateError.getMessage());

            }
        }) {

            @Override
            protected Map<String, String> getParams() {
                // POST parameters to registration url
                Log.d("long",locate.get(0).toString()+ " " + uid );
                Map<String, String> parameters = new HashMap<String, String>();
                parameters.put("tag", "fetchsongs");
                parameters.put("uid",uid);
                parameters.put("lat", locate.get(0).toString());
                parameters.put("long", locate.get(1).toString());

                return parameters;
            }

        };

        AppManager.getInstance().addToRequestQueue(stringRequest, tag_string_req);
    }


}

