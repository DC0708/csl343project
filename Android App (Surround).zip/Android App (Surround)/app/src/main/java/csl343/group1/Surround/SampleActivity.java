package csl343.group1.Surround;

/**
 * Created by root on 18/4/15.
 */
//import vatsag.samples.weatherdisplay.R;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;


public class SampleActivity extends Activity {

    String position = "1";
    String city = "";
    String weather = "";
    String temperature = "";
    String windSpeed = "";
    String iconfile = "";
    ImageButton imgWeatherIcon;

    TextView tvcity;
    TextView tvtemp;
    TextView tvwindspeed;
    TextView tvCondition;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.detailpage);

        try {

            //handle for the UI elements
            imgWeatherIcon = (ImageButton) findViewById(R.id.imageButtonAlpha);
            //Text fields
            tvcity = (TextView) findViewById(R.id.textViewCity);
            tvwindspeed = (TextView) findViewById(R.id.textViewWindSpeed);

          //  tvtemp = (TextView) findViewById(R.id.textViewTemperature);

            tvCondition = (TextView) findViewById(R.id.textViewCondition);

            Log.e("you","are trolled");
            // Get position to display
            Intent i = getIntent();

        //    this.position = i.getStringExtra("");
            this.city = i.getStringExtra("name");
            Log.e("you","are trolled");
            this.weather=	i.getStringExtra("album_movie");
            Log.e("you","are trolled");
         //   this.temperature =  i.getStringExtra("temperature");
            this.windSpeed =  i.getStringExtra("artist_band");
            Log.e("you","are trolled");
       //     this.iconfile = i.getStringExtra("icon");

  //          String uri = "drawable/"+ "d" + iconfile;
//            int imageBtnResource = getResources().getIdentifier(uri, null, getPackageName());
//            Drawable dimgbutton = getResources().getDrawable(imageBtnResource);


            //text elements
            tvcity.setText(city);
            Log.e("you","are trolled");
//            tvtemp.setText(temperature);
            Log.e("you","are trolled");
            tvwindspeed.setText(windSpeed);
            Log.e("you","are trolled");
            tvCondition.setText(weather);
            Log.e("you","are trolled");
            Log.e("you",tvwindspeed.getText().toString());

            //thumb_image.setImageDrawable(image);
//            imgWeatherIcon.setImageDrawable(dimgbutton);


        }

        catch (Exception ex) {
            Log.e("Error", "Loading exception");
        }

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }
}
