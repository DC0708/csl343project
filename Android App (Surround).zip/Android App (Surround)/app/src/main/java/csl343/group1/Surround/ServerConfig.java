/**
 * Author: Aditya Abhas
 * Entry No: 2012csb1002
 *
 * Configure the login and registration urls.
 * */

package csl343.group1.Surround;

public class ServerConfig {
    public static final String BASE_ADDRESS = "http://10.1.13.29/";
	public static final String LOGIN_URL = BASE_ADDRESS + "android_login_api/";
	public static final String REGISTER_URL = BASE_ADDRESS + "android_login_api/";
}
